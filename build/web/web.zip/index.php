<html>
<head>
	<title>Imposter PDFs</title>
	<style type="text/css">
		body{
			margin:40px auto;
			max-width:650px;
			line-height:1.6;
			font-size:18px;
			color:#444;
			padding:010px;
			background-color: #FFFFFF;
		}
		h1,h2,h3{
			line-height:1.2;
		}
		a{
			text-decoration: none;
			color: blue;
		}
		a:hover{
			text-decoration: underline;
		}
	</style>
</head>
<body>
	<h1>PDF Files:</h1>
	<a href="./Files/Cake.pdf">Cake.pdf</a><br />
	<a href="./Files/Cookies.pdf">Cookies.pdf</a><br />
	<a href="./Files/Keyboard.jpg.pdf">Keyboard.jpg.pdf</a><br />
	<a href="./Files/Oranges.pdf">Oranges.pdf</a>
</body>
</html>