<html>
<head>
	<title>Imposter PDFs</title>
</head>
<body>
	<h1>PDF Files:</h1>
	<a href="./Files/Cake.pdf">Cake.pdf</a><br />
	<a href="./Files/Cookies.pdf">Cookies.pdf</a><br />
	<a href="./Files/Keyboard.jpg.pdf">Keyboard.jpg.pdf</a><br />
	<a href="./Files/Oranges.pdf">Oranges.pdf</a>
</body>
</html>